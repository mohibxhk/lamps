# GIANNI GABUTTI — Official Website

Premium bilingual (IT/EN) website for **Gianni Gabutti**, Italian architectural lighting company based in San Martino, Italy.

Design direction: contemporary Italian design, quiet luxury, editorial layouts, architectural monochrome palette (`#F8F8F6` paper, `#111110` ink, warm stone grays), Apple SF Pro system typography stack (SF Pro Display / SF Pro Text, falling back to Helvetica Neue / Arial), Lenis smooth scrolling, Framer Motion reveals, slow editorial marquee.

---

## 1. Technology stack

- **Frontend**: React 19 (CRA + CRACO), React Router 7, Tailwind CSS 3, Framer Motion 11, Lenis, lucide-react
- **Backend**: FastAPI (Python 3), Motor (async MongoDB driver), Pydantic v2
- **Database**: MongoDB (products, projects, enquiries)
- **i18n**: centralized translation dictionaries (`src/i18n/translations.js`), IT default, persisted in `localStorage`

## 2. Project structure

```
/app
├── backend/
│   ├── server.py            # FastAPI app: routes, models, seed, rate limiting
│   ├── requirements.txt
│   └── .env                 # real environment (never commit secrets)
├── frontend/
│   ├── public/
│   │   ├── index.html       # fonts, base meta, favicon
│   │   ├── favicon.svg      # GG monogram favicon
│   │   ├── robots.txt
│   │   ├── sitemap.xml
│   │   └── assets/          # PUT YOUR IMAGES / VIDEO / LOGO HERE
│   └── src/
│       ├── config/site.js   # ★ CENTRAL ASSET + CONTACT CONFIG (see below)
│       ├── i18n/            # translations.js + LanguageContext
│       ├── lib/api.js       # axios API layer
│       ├── components/      # Header, Footer, ImageSlot, ChatWidget, EnquiryForm, …
│       └── pages/           # Home, Products, ProductDetail, Projects, ProjectDetail,
│                            # About, Services, Contact, Legal, NotFound
├── .env.example
└── README.md
```

## 3. Prerequisites

- Node.js 18+ and **yarn** (never npm)
- Python 3.11+
- MongoDB (local or hosted)

## 4. Installation

```bash
cd backend  && pip install -r requirements.txt
cd frontend && yarn install
```

## 5. Environment variables

Copy `.env.example` values into the two real env files:

`backend/.env`
```
MONGO_URL="mongodb://localhost:27017"
DB_NAME="gianni_gabutti"
CORS_ORIGINS="*"
```

`frontend/.env`
```
REACT_APP_BACKEND_URL=<public URL of the backend, no trailing slash>
```

## 6. Development

```bash
# backend (port 8001)
cd backend && uvicorn server:app --host 0.0.0.0 --port 8001 --reload
# frontend (port 3000)
cd frontend && yarn start
```

All backend routes are prefixed with `/api`. On first startup the backend seeds 6 demo products and 4 demo projects (all flagged `demo: true`) so every layout is visible immediately.

## 7. Production build

```bash
cd frontend && yarn build
```

Serve `frontend/build/` statically and proxy `/api/*` to the FastAPI service.

## 8. API endpoints

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/products?category=&q=` | List products (filterable) |
| GET | `/api/products/{slug}` | Product detail |
| GET | `/api/projects?category=` | List projects |
| GET | `/api/projects/{slug}` | Project detail |
| POST | `/api/enquiries` | Store an enquiry (validated, honeypot, rate-limited, privacy consent required) |
| POST | `/api/chat` | Chatbot skeleton — returns `{configured:false, reply}` stub until an LLM is connected |

## 9. Database

MongoDB collections: `products`, `projects`, `enquiries`. Models are defined in `backend/server.py` (`Product`, `Project`, `Enquiry`) with localized `{it, en}` text fields. To replace demo content, delete documents where `demo: true` and insert real ones (same schema), or extend the API with an admin interface later.

## 10. Chatbot configuration (section 11 of the brief)

The UI panel + `POST /api/chat` endpoint are complete. The endpoint currently returns a clearly-labelled stub (`configured: false`) — **no AI provider is connected**. To connect one: add the provider key to `backend/.env`, implement the call inside the `/api/chat` handler in `backend/server.py` (marked with a comment), keep all credentials server-side, and return `{configured: true, reply: ...}`. Rate limiting (20 req/min/IP) is already in place.

## 11. Email notifications

Not configured by design. Enquiries are stored in the `enquiries` collection. To add email, integrate a provider (e.g. Resend) inside `POST /api/enquiries`.

## 12. Replacing the logo, images and hero video

**Everything is configured in one file: `frontend/src/config/site.js`.**

1. Copy your files into `frontend/public/assets/` (create subfolders like `assets/products/`).
2. In `site.js`, replace the relevant `null` with the public path, e.g.:
   - Logo: `logo: "/assets/brand/logo.svg"`
   - Hero: `hero: { video: "/assets/hero/hero.mp4", poster: "/assets/hero/poster.jpg" }`
   - Product main shot: `products.bruma.main = "/assets/products/bruma-01.jpg"`
3. No component or layout changes are needed — every slot keeps its exact aspect ratio and crop.

Any slot left as `null` renders the labelled placeholder (“You can upload your image here” / “You can upload your video here”).

Recommended ratios: product shots **3:4 portrait**, project shots **16:9 landscape**, editorial banner **21:9**, hero video **16:9 or wider**, compressed (H.264, < 10 MB).

## 13. Managing products, projects and translations

- **Products / projects**: documents in MongoDB (see §9). Product images map to slugs via `ASSETS.products[slug]` in `site.js`.
- **Translations**: all UI text lives in `frontend/src/i18n/translations.js` (`it` + `en` trees). The language switcher persists the choice in `localStorage` (`gg_lang`) and updates `<html lang>` plus page metadata.
- **Contact details**: `SITE.contact` in `site.js` (address, phone, email, hours) — currently `null`, shown as “to be confirmed”.

## 14. Legal pages

`/legal` contains clearly-marked **draft** privacy/cookie/legal sections. They must be reviewed and completed by the company (legal name, VAT, registered office, GDPR details) before publication.

## 15. Known limitations / pending configuration

- Hero video, logo and all photography are placeholders until the client supplies assets (by design).
- Chatbot AI provider not connected (stub endpoint, documented above).
- Email notifications for enquiries not configured (database storage only).
- Legal texts are drafts.
- No fabricated company facts: history, awards, testimonials and real contact details are intentionally absent until supplied.

## 16. Testing checklist (verified during development)

- All routes render on desktop (1366px) and mobile (375px), incl. fullscreen mobile menu
- IT ↔ EN switcher works and persists across navigation
- Product catalogue filtering + search; product detail gallery/specs/enquiry link
- Project archive + detail with products-used relationships
- Contact form: client + server validation, honeypot spam rejection, success/error states, records stored in MongoDB
- Chat panel: open/close, message flow, stub reply, demo-mode labelling
- Backend endpoints verified with curl; no Emergent branding anywhere in the UI
